var url = "bd/crud.php";

var appMoviles = new Vue({    
el: "#empleados",   
data:{     
     empleados:[],          
    areas: [],
      roles:[],
      
 },    
  methods: {
    //BOTONES        
 
    btnEditar: async function (id, nombre, email, sexo, areas_idareas) {
      
      
      await Swal.fire({
        title: 'EDITAR',
        html:
          '<div class="form-group"><div class="row"><label class="col-sm-3 col-form-label">nombre</label><div class="col-sm-7"><input id="nombre" value="' + nombre + '" type="text" class="form-control"></div></div><div class="row"><label class="col-sm-3 col-form-label">email</label><div class="col-sm-7"><input id="email" value="' + email + '" type="text" class="form-control"></div></div><div class="row"><label class="col-sm-3 col-form-label">sexo</label><div class="col-sm-7"><input max="1" id="sexo" value="' + sexo + '" type="text" min="0" class="form-control"></div></div></div>',
        focusConfirm: false,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          nombre = document.getElementById('nombre').value,
            email = document.getElementById('email').value,
            sexo = document.getElementById('sexo').value,
            
            this.editarMovil(id, nombre, email, sexo);
          Swal.fire(
            '¡Actualizado!',
            'El registro ha sido actualizado.',
            'success'
          )
        }
      });
        
    },
    btnBorrar: function (id,nombre) {
      Swal.fire({
        title: '¿Está seguro de borrar el registro: ' + nombre + " ?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Borrar'
      }).then((result) => {
        if (result.value) {
          this.borrarempleado(id);
          //y mostramos un msj sobre la eliminación  
          Swal.fire(
            '¡Eliminado!',
            'El registro ha sido borrado.',
            'success'
          )
        }
      })
    },
    
    //PROCEDIMIENTOS para el CRUD     
    listarEmpleados: function () {
      axios.post(url, { opcion: 4 }).then(response => {
        this.empleados = response.data;
          
      });
    },
  
    //Procedimiento EDITAR.
    editarMovil: function (id, nombre, email, sexo) {
      axios.post(url, { opcion: 2, id: id, nombre: nombre, email: email, sexo: sexo }).then(response => {
        this.listarEmpleados();
      });
    },
    //Procedimiento BORRAR.
    borrarempleado: function (id) {
      axios.post(url, { opcion: 3, id: id }).then(response => {
        this.listarEmpleados();
      });
    },
    //LISTAR AREAS

    listarAreas: function () {
      axios.post(url, { opcion: 5 }).then(response => {
        this.areas = response.data;
      });
    
    
    },
    listarRoles: function () {
      axios.post(url, { opcion: 6 }).then(response => {
        this.roles = response.data;
      });
    },

  },
created: function(){            
  this.listarEmpleados();
  this.listarAreas();
  this.listarRoles();
},    
computed:{
    
}    
});