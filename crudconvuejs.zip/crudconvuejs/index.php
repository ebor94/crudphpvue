<!doctype html>
<html>
    <head>
    <link rel="shortcut icon" href="#" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- FontAwesom CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">        
    <!--Sweet Alert 2 -->
    <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.min.css">        
    <!--CSS custom -->  
    <link rel="stylesheet" href="main.css">  
    </head>
    <body>
    <header>
        <h2 class="text-center text-dark"><span class="badge badge-success">CRUD con VUE.JS-PHP</span></h2>
    </header>    
    
     <div id="empleados">               
        <div class="container">                
            <!-- <div class="row">       
                <div class="col">        
                    <button @click="btnAlta" class="btn btn-primary" title="Nuevo"> Registrar Empleado</i></button>
                </div>


                
                  
            </div>                 -->
             <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
        Resgistrar Empleado
  </button> 
            <div class="row mt-5">
                <div class="col-lg-12">                    
                    <table class="table table-striped">
                        <thead>
                            <tr class="bg-primary text-light">
                                <th>ID</th> 
                                <th>Nombre</th>                                   
                                <th>Email</th>
                                <th>Sexo</th>
                                <th>Area</th>
                                <th>Boletin</th>   
                                <th>Acciones</th>
                            </tr>    
                        </thead>
                        <tbody>
                            <tr v-for="(empleado,indice) of empleados">                                
                                <td>{{empleado.idEmpleados}}</td>                                
                                <td>{{empleado.nombre}}</td>
                                <td>{{empleado.email}}</td>
                                <td>{{empleado.sexo}}</td> 
                                 <td>{{empleado.areas_idareas}}</td>
                              
                                 <td v-if ="empleado.boletin = 1">si</td>
                                <td v-if ="empleado.boletin = 0">No</td> 
                                                               
                                  
                              
                                <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-secondary" title="Editar" @click="btnEditar(empleado.idEmpleados, empleado.nombre, empleado.email, empleado.areas_idareas,empleado.boletin)"><i class="fas fa-pencil-alt"></i></button>    
                                    <button class="btn btn-danger" title="Eliminar" @click="btnBorrar(empleado.idEmpleados,empleado.nombre)"><i class="fas fa-trash-alt"></i></button>      
								</div>
                                </td>
                            </tr>    
                        </tbody>
                    </table>                    
                </div>
            </div>
        </div>  
        
        <div class="collapse" id="collapseExample">
  <div class="card card-body">
      
       <div class="container">
          
 <form method="post">
   <div class="form-group">
    <label for="Nombre"><b>Nombre Completo</b></label>
    <input type="text" class="form-control" id="Nombre" placeholder="Nombre completo de empleado">
  </div>         
  <div class="form-group">
    <label for="email"><b>Correo Electronico</b></label>
    <input type="email" class="form-control" id="email" placeholder="Correo Electronico">
  </div>

  <div class="form-check">
      
  <input class="form-check-input" type="radio" name="sexo" id="sexo" value="M" checked>
  <label class="form-check-label" for="exampleRadios1">
    Masculino
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="sexo" id="sexo" value="F">
  <label class="form-check-label" for="exampleRadios2">
    Femenino
  </label>
</div>

  <div class="form-group">
    <label for="exampleFormControlSelect1"><b>Area</b></label>
    <select class="form-control" id="Area">
      <option v-for="Area in areas" :value="Area.ideareas">{{Area.nombre}}</option>
    </select>
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1"><b>Descripcion</b></label>
    <textarea class="form-control"   placeholder="Descripcion experiencia del empleado" id="experiencia" rows="3"></textarea>
  </div>
<fieldset class="form-group row">
    <legend class="col-form-label col-sm-2 float-sm-left pt-0"><b>Boletin</b></legend>
  <div class="form-group row">
    <div class="col-sm-10 offset-sm-2">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="boletin">
        <label class="form-check-label" for="gridCheck1">
          Deseo Recibir Boletin informativo
        </label>
      </div>
    </div>
  </div>
   </fieldset>
  <fieldset class="form-group row">
    <legend class="col-form-label col-sm-2 float-sm-left pt-0"><b>Roles</b></legend>
    <div class="form-group row">
    <div class="col-sm-10 offset-sm-2">
      <div   v-for="Rol in roles" class="form-check">
        <input class="form-check-input" type="checkbox" >
        <label   class="form-check-label" for="gridCheck1">
          {{Rol.nombre}}
        </label>
      </div>
    </div>
  </div>
  </fieldset>
</form>
           </div>
      
  </div>
</div>
     
       
    </div>        
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>         
    <!--Vue.JS -->    
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>              
    <!--Axios -->      
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.15.2/axios.js"></script>    
    <!--Sweet Alert 2 -->        
    <script src="plugins/sweetalert2/sweetalert2.all.min.js"></script>      
    <!--Código custom -->          
    <script src="main.js"></script>         
    </body>
</html>