-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 28, 2021 at 03:01 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empleados`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `insertEmployed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertEmployed` (`nombre` VARCHAR(255), `email` VARCHAR(255), `sexo` CHAR(1), `boletin` INT, `descripcion` TEXT, `area` INT, `rol` INT, `idem` INT)  BEGIN
declare
id int ;
declare
cod int ;

declare 
mensaje varchar(30);

select  count(idEmpleados) into cod from empleados where idEmpleados = idem ;

if cod =0 then

insert into  empleados  (nombre, email, sexo, boletin, descripcion, areas_idareas) values  (nombre,email,sexo,boletin,descripcion,area);
select  max(idEmpleados) into id  from  empleados;

insert  into  roles_has_empleados values (rol,id,area);
set mensaje ="registro exitoso"; 
 end if;
 
 if cod = 1 then
 
 update roles_has_empleados set Roles_idRoles = rol where Empleados_idEmpleados =  idem and areas_idAreas=area ;
update empleados set  nombre=nombre, email=email, sexo=sexo, boletin=boletin, descripcion=descripcion, areas_idareas=area where idEmpleados = idem;
set mensaje ="registro actualizado"; 
 end if;
 
 
 select mensaje ;


END$$

DROP PROCEDURE IF EXISTS `listEmployed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listEmployed` ()  BEGIN

SELECT empleados.idEmpleados ,empleados.nombre ,empleados.email ,empleados.sexo ,empleados.boletin ,empleados.descripcion  ,areas.nombre nomarea FROM empleados
INNER JOIN areas
on empleados.areas_idareas = areas.idAreas;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
CREATE TABLE IF NOT EXISTS `areas` (
  `idareas` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`idareas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `areas`
--

INSERT INTO `areas` (`idareas`, `nombre`) VALUES
(1, 'TI'),
(2, 'Contabilidad'),
(3, 'Cartera'),
(4, 'Recursos Humanos');

-- --------------------------------------------------------

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
CREATE TABLE IF NOT EXISTS `empleados` (
  `idEmpleados` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sexo` char(1) NOT NULL,
  `boletin` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `areas_idareas` int(11) NOT NULL,
  PRIMARY KEY (`idEmpleados`,`areas_idareas`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `empleados`
--

INSERT INTO `empleados` (`idEmpleados`, `nombre`, `email`, `sexo`, `boletin`, `descripcion`, `areas_idareas`) VALUES
(22, 'edwin', 'ebor94@hotmail.com', 'M', 1, 'asd', 2);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `idRoles` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idRoles`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`idRoles`, `nombre`) VALUES
(1, 'Director'),
(2, 'Auxiliar'),
(3, 'Desarrollador');

-- --------------------------------------------------------

--
-- Table structure for table `roles_has_empleados`
--

DROP TABLE IF EXISTS `roles_has_empleados`;
CREATE TABLE IF NOT EXISTS `roles_has_empleados` (
  `Roles_idRoles` int(11) NOT NULL,
  `Empleados_idEmpleados` int(11) NOT NULL,
  `areas_idAreas` int(11) NOT NULL,
  PRIMARY KEY (`Roles_idRoles`,`Empleados_idEmpleados`,`areas_idAreas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles_has_empleados`
--

INSERT INTO `roles_has_empleados` (`Roles_idRoles`, `Empleados_idEmpleados`, `areas_idAreas`) VALUES
(1, 5, 1),
(1, 6, 1),
(1, 7, 1),
(1, 8, 1),
(1, 9, 1),
(1, 10, 1),
(1, 11, 1),
(1, 12, 1),
(1, 13, 1),
(1, 14, 1),
(1, 15, 1),
(1, 16, 1),
(1, 17, 1),
(2, 18, 3),
(2, 20, 3),
(2, 21, 4),
(3, 1, 1),
(3, 19, 4),
(3, 22, 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
