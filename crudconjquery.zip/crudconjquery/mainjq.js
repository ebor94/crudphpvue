var url = "bd/crud.php";
$(document).ready(function () {
listarEmpleados();
  listarAreas();
  listarRoles();
});

function listarEmpleados() {
     axios.post(url, { opcion: 4 }).then(response => {
         empleados = response.data;
          console.log(empleados)
        
         for (var i = 0; i < empleados.length; i++){
             boletin = empleados[i]["boletin"];
             if (boletin === "1") {
                 boletin = "si"
             } else {boletin = "no" }

             eliminar = ' <button class="btn btn-danger" onclick="deleteempleado('+ empleados[i]["idEmpleados"] +')" type="button" ><i class="far fa-trash-alt"></i> </button>'
             editar  =' <button class="btn btn-primary" onclick="editarempleado('+ empleados[i]["idEmpleados"] +')" type="button" ><i class="far fa-edit"></i> </button>'
             
          $("#tabla").append("<tr align='center' class='danger'><td>" + empleados[i]["idEmpleados"]+ "</td>"+"<td>" + empleados[i]["nombre"] + "<td>" + empleados[i]["email"]+ "</td><td>" + empleados[i]["sexo"]+ "</td><td>" + empleados[i]["nomarea"]+ "</td><td>" + boletin+ "</td><td>"+eliminar +editar+"</td></tr>");   
             
      //  alert(empleados[i]["nombre"]);
}
         

      });
}



function deleteempleado(id){
    
      axios.post(url, { opcion: 3, id: id }).then(response => {
          location.reload()
      });
}

function editarempleado(id){
    
    axios.post(url, { opcion: 7, id: id }).then(response => {
        empleado = response.data;
        console.log(empleado)
        cod=$("#cod").val(empleado[0]["idEmpleados"]);
         Nombre=$("#Nombre").val(empleado[0]["nombre"]);
        email = $("#email").val(empleado[0]["email"]);
        $("input[name=sexo][value=" + empleado[0]["sexo"] + "]").prop("checked", true);
        boletin = empleado[0]["boletin"];
        //alert(boletin)
        if (boletin === "0") {
         $("input[name=boletin]").prop("checked",false);            
        }
        if (boletin ==="1") {
         $("input[name=boletin]").prop("checked",true);            
        }
        $("input[name=rol][value=" + empleado[0]["Roles_idRoles"] + "]").prop("checked", true);       
         Area = $("#Area").val(empleado[0]["areas_idareas"]);   
        descripcion=$("#experiencia").val(empleado[0]["descripcion"]);

        $('#exampleModal').modal('show')
      
      });
}



function listarAreas() {


     axios.post(url, { opcion: 5 }).then(response => {
         areas = response.data;
         for (var i = 0; i < areas.length; i++) {
             $("#Area").append("<option value="+areas[i]["idareas"]+">"+areas[i]["nombre"]+"</option>")
             
         }

        // console.log(empleados)
          
      });
}

function listarRoles() {

     axios.post(url, { opcion: 6 }).then(response => {
         rol = response.data;

         for (var i = 0; i < rol.length; i++) {    
             $("#rols").append('<input class="form-check-input" name="rol" id="rol" value='+rol[i]["idRoles"]+' type="checkbox" > '+rol[i]["nombre"]+'</input><br> ')
             
         }
       //  console.log(rol)
          
      });

}





$("#registrar").click(function () {
     boletin=0
    $('#rol:checked').each(
    function() {
           // alert("El checkbox con valor " + $(this).val() + " está seleccionado");
            rol=$(this).val()
    }
    );

    $('#boletin:checked').each(
    function() {
           // alert("El checkbox con valor " + $(this).val() + " está seleccionado");
            boletin=1
    }
    );
    
    cod = $("#cod").val();
    if (cod === "") {
        cod=0
    }
    Nombre=$("#Nombre").val();
    email=$("#email").val();
    sexo=$('input:radio[name=sexo]:checked').val()
    Area = $("#Area").val();    
    descripcion=$("#experiencia").val();
    
   alert(sexo)
    axios.post(url, { opcion: 1, Nombre: Nombre, email: email, sexo: sexo, Area: Area, descripcion: descripcion, boletin: boletin, rol:rol, cod:cod }).then(response => {
        MENSAJE = response.data;
        $('#exampleModal').modal('hide')
         location.reload()
        
        //alert(MENSAJE)
          
      });

});