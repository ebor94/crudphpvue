<!doctype html>
<html>
    <head>
    <link rel="shortcut icon" href="#" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">    <!-- FontAwesom CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">        
    <!--Sweet Alert 2 -->
    <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.min.css">        
    <!--CSS custom -->  
    <link rel="stylesheet" href="main.css">  
    </head>
    <body>
    <header>
        <h2 class="text-center text-dark"><span class="badge badge-success">CRUD con jQuey-PHP</span></h2>
    </header>    
    
     <div id="empleados">               
        <div class="container">                
            <!-- <div class="row">       
                <div class="col">        
                    <button @click="btnAlta" class="btn btn-primary" title="Nuevo"> Registrar Empleado</i></button>
                </div>


                
                  
            </div>                 -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Nuevo Empleado
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Registro de Empleados</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post">
   <div class="form-group">
    <label for="Nombre"><b>Nombre Completo</b></label>
    <input type="text" class="form-control" id="Nombre" placeholder="Nombre completo de empleado">
    <input style="display:none" type="number" class="form-control" id="cod">
  </div>         
  <div class="form-group">
    <label for="email"><b>Correo Electronico</b></label>
    <input type="email" class="form-control" id="email" placeholder="Correo Electronico">
  </div>

  <div class="form-check">
      
  <input class="form-check-input" type="radio" name="sexo" id="sexo" value="M" checked>
  <label class="form-check-label" for="exampleRadios1">
    Masculino
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="sexo" id="sexo" value="F">
  <label class="form-check-label" for="exampleRadios2">
    Femenino
  </label>
</div>

  <div class="form-group">
    <label for="exampleFormControlSelect1"><b>Area</b></label>
    <select class="form-control" id="Area">
      
    </select>
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1"><b>Descripcion</b></label>
    <textarea class="form-control"   placeholder="Descripcion experiencia del empleado" id="experiencia" rows="3"></textarea>
  </div>
<fieldset class="form-group row">
    <legend class="col-form-label col-sm-2 float-sm-left pt-0"><b>Boletin</b></legend>
  <div class="form-group row">
    <div class="col-sm-10 offset-sm-2">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" name="boletin" id="boletin">
        <label class="form-check-label" for="gridCheck1">
          Deseo Recibir Boletin informativo
        </label>
      </div>
    </div>
  </div>
   </fieldset>
  <fieldset class="form-group row">
    <legend class="col-form-label col-sm-2 float-sm-left pt-0"><b>Roles</b></legend>
    <div class="form-group row">
    <div class="col-sm-10 offset-sm-2">
       <div  class="form-check" id="rols">
       
      </div>
    </div>
  </div>
  </fieldset>

      </div>
      <div class="modal-footer">
       <button type="button" id="registrar" class="btn btn-dark">REgistrar Empleado</button>

</form>
      </div>
    </div>
  </div>
</div> 
            <div class="row mt-5">
                <div class="col-lg-12">                    
                    <table class="table table-striped" id="tabla">
                        <thead>
                            <tr class="bg-primary text-light">
                                <th>ID</th> 
                                <th><i class="far fa-user"></i> Nombre</th>                                   
                                <th><i class="fas fa-at"></i> Email</th>
                                <th><i class="fas fa-at"></i> Sexo</th>
                                <th><i class="fas fa-briefcase"></i> Area</th>
                                <th><i class="far fa-envelope"></i> Boletin</th>   
                                <th>Acciones</th>
                            </tr>    
                        </thead>
                        <tbody>
                            <!-- <tr v-for="(empleado,indice) of empleados">                                
                                <td>{{empleado.idEmpleados}}</td>                                
                                <td>{{empleado.nombre}}</td>
                                <td>{{empleado.email}}</td>
                                <td>{{empleado.sexo}}</td> 
                                 <td>{{empleado.areas_idareas}}</td>
                              
                                 <td v-if ="empleado.boletin = 1">si</td>
                                <td v-if ="empleado.boletin = 0">No</td> 
                                                               
                                  
                              
                                <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-secondary" title="Editar" @click="btnEditar(empleado.idEmpleados, empleado.nombre, empleado.email, empleado.areas_idareas,empleado.boletin)"><i class="fas fa-pencil-alt"></i></button>    
                                    <button class="btn btn-danger" title="Eliminar" @click="btnBorrar(empleado.idEmpleados,empleado.nombre)"><i class="fas fa-trash-alt"></i></button>      
								</div>
                                </td>
                            </tr>     -->
                        </tbody>
                    </table>                    
                </div>
            </div>
        </div>  
        
        <div class="collapse" id="collapseExample">
  <div class="card card-body">
      
       <div class="container">
          
 
           </div>
      
  </div>
</div>
     
       
    </div>     
    
    
    <div class="modal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>         
    <!--Vue.JS  
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>  -->               
    <!--Axios -->      
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.15.2/axios.js"></script>    
    <!--Sweet Alert 2 -->        
    <script src="plugins/sweetalert2/sweetalert2.all.min.js"></script>      
    <!--Código custom -->          
    <script src="mainjq.js"></script>         
    </body>
</html>