<?php
include_once 'conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$_POST = json_decode(file_get_contents("php://input"), true);


$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';


$id = (isset($_POST['id'])) ? $_POST['id'] : '';
$nombre = (isset($_POST['nombre'])) ? $_POST['nombre'] : '';
$email = (isset($_POST['email'])) ? $_POST['email'] : '';
$sexo = (isset($_POST['sexo'])) ? $_POST['sexo'] : '';
$boletin =   (isset($_POST['boletin'])) ? $_POST['boletin'] : '';
$area =   (isset($_POST['area'])) ? $_POST['area'] : '';
$rol =   (isset($_POST['rol'])) ? $_POST['rol'] : '';

//$opcion="4";

switch($opcion){
    case 1:
        $consulta = "call insertEmployed('$nombre', '$email', '$sexo', $boletin, '$descripcion', $area, $rol) ";	
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                
        break;
    case 2:
        //$consulta = "UPDATE empleados SET nombre='$nombre', email='$email', sexo='$sexo'  , boletin=$boletin, area=$area WHERE idEmpleados='$id' ";		
        $consulta = "call UpdateEmployed($id,'$nombre', '$email', '$sexo', $boletin, '$descripcion', $area, $rol)";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                        
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3:
        $consulta = "DELETE FROM empleados WHERE idEmpleados=$id ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break;         
    case 4:
        $consulta = "SELECT * FROM empleados";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 5:
        $consulta = "SELECT * FROM areas";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break; 
      case 6:
        $consulta = "SELECT * FROM roles";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;            
}
print json_encode($data, JSON_UNESCAPED_UNICODE);
$conexion = NULL;