<?php
include_once 'conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$_POST = json_decode(file_get_contents("php://input"), true);


$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';


$id = (isset($_POST['id'])) ? $_POST['id'] : '';
$nombre = (isset($_POST['Nombre'])) ? $_POST['Nombre'] : '';
$email = (isset($_POST['email'])) ? $_POST['email'] : '';
$sexo = (isset($_POST['sexo'])) ? $_POST['sexo'] : '';
$boletin =   (isset($_POST['boletin'])) ? $_POST['boletin'] : '';
$area =   (isset($_POST['Area'])) ? $_POST['Area'] : '';
$rol =   (isset($_POST['rol'])) ? $_POST['rol'] : '';
$cod =   (isset($_POST['cod'])) ? $_POST['cod'] : '';
$descripcion =   (isset($_POST['descripcion'])) ? $_POST['descripcion'] : '';

//$opcion="1";
$data = "";
switch($opcion){
    case 1:
        $consulta = "call insertEmployed('$nombre', '$email', '$sexo', $boletin, '$descripcion', $area, $rol, $cod) ";
        //$consulta ="call insertEmployed ('prueba','prueba','M',1,'prueba',1,1)";  
        //$data=$consulta ;   
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();   
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        $data=$consulta ;              
        break;
    case 2:
        $consulta = "UPDATE empleados SET nombre='$nombre', email='$email', sexo='$sexo'  WHERE idEmpleados=$id ";		
       // $consulta = "call UpdateEmployed($id,'$nombre', '$email', '$sexo', $boletin, '$descripcion', $area, $rol)";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                        
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3:
        $consulta = "DELETE FROM empleados WHERE idEmpleados=$id ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break;         
    case 4:
        $consulta = "call listEmployed()";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 5:
        $consulta = "SELECT * FROM areas";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break; 
      case 6:
        $consulta = "SELECT * FROM roles";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break; 
         case 7:
        $consulta = "SELECT empleados.idEmpleados ,empleados.nombre ,empleados.email ,empleados.sexo ,empleados.boletin ,empleados.descripcion ,empleados.areas_idareas ,roles_has_empleados.Roles_idRoles FROM empleados INNER JOIN roles_has_empleados on empleados.areas_idareas = roles_has_empleados.areas_idAreas  WHERE idEmpleados=$id ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;              
}
print json_encode($data, JSON_UNESCAPED_UNICODE);
$conexion = NULL;